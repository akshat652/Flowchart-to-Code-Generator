def calculate_sum():
    # Step 2: Declare variables
    num1 = float(input("Enter the first number: "))
    num2 = float(input("Enter the second number: "))
    
    # Step 4: Calculate sum
    sum_result = num1 + num2
    
    # Step 5: Display sum
    print("The sum of", num1, "and", num2, "is:", sum_result)

# Call the function to execute
calculate_sum()